package org.bwillard.ccsf.course.cs211s.assn1;

public enum InstrumentType {

	GUITAR, VIOLIN, PIANO, DRUMS
}
