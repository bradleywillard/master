package org.bwillard.ccsf.course.cs211s.assn1;

public enum StringType {

	STEEL,
	NYLON,
	ELECTRIC,
	BASS,
	CUT_GORE,
	STEEL_GORE,
	SYNTHETIC_CORE
}
