package org.bwillard.ccsf.course.cs211s.assn1;

public enum Acoustic {
	STEEL_STRING,
	NYLON_STRING,
	BASS;
}
