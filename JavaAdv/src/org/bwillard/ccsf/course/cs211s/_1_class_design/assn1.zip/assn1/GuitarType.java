package org.bwillard.ccsf.course.cs211s.assn1;

public enum GuitarType {

	ACOUSTIC,
	ELECTRIC,
	BASS;
}
