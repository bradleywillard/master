package org.bwillard.ccsf.course.cs211s.assn1;

public enum PianoType {

	ORGAN,
	GRAND,
	UPRIGHT,
	SQUARE
	
	
}
