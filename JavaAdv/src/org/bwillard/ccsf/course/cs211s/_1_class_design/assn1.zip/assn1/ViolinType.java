package org.bwillard.ccsf.course.cs211s.assn1;

public enum ViolinType {

	VIOLIN,
	VIOLA,
	CELLO,
	BASS
}
