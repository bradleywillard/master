package org.bwillard.ccsf.course.cs211s.assn5.instruments;

public interface Player {
	
	void play();
	void tune();
	void repair();
}
