package org.bwillard.ccsf.course.cs211s.midTerm;

public interface Graduator {
	
	void printGraduationRequirements(String type, String name);
}
