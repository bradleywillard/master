package org.bwillard.ccsf.course.cs211s.assn3;

public interface Player {
	
	void play();
	void tune();
	void repair();
}
