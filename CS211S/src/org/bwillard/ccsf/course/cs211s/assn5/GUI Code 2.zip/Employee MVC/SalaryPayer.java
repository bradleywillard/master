
public class SalaryPayer implements Payer {

	public SalaryPayer() {
		
	}
	public String runPayroll() {
		return "Paying via salary.";
	}
}
