
public interface Payer {

	public String runPayroll();
}
