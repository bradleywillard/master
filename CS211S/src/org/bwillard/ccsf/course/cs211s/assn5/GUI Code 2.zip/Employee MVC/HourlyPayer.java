
public class HourlyPayer implements Payer {

	public HourlyPayer() {
		
	}
	public String runPayroll() {
		return "Paying via hourly.";
	}
}
